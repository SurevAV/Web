import os
import sqlite3
import uuid
import datetime


def sql_work(item, is_request):
    """
    Выполняет работу
    """
    os.chdir(os.path.join(os.path.dirname(__file__), 'sql'))
    con = sqlite3.connect('main.db', check_same_thread=False)
    cur = con.cursor()
    if is_request:
        response = list(cur.execute(item))
        con.commit()
        con.close()
        return response 
    else:
        cur.execute(item)
    con.commit()
    con.close()

def list_titles():
    """
    Возвращает список названий всех статей
    """ 
    response = sql_work("SELECT Title FROM Articles GROUP BY Title",True)
    article = ''
    for item in response:
        article = article + item[0]+'\n'
    title = 'Список всех записей'
    return article, title

def delete_article(title):
    """
    Удаляет запись по названию
    """ 
    return sql_work("DELETE FROM Articles WHERE Title='"+title+"'",False)

def id_article(title):
    """
    Находит ид записи по названию
    """ 
    return sql_work("SELECT Id FROM Articles WHERE Title='"+title+"'",True)[0][0]

def delete_comments(id_article):
    """
    Удаляет комментарии по ид записи
    """ 
    return sql_work("DELETE FROM Comments WHERE IdArticle='"+id_article+"'",False)

def change_article(title, article, image):
    """
    Изменяет запись найденную по названию
    """ 
    return sql_work("UPDATE Articles SET Title='"+title+"', Article='"+article+"', Image='/static/images/"+image+"' WHERE Title='"+title+"'",False)

def search_article(title):
    """
    Ищет запись по названию
    """ 
    response = sql_work("SELECT * FROM Articles WHERE Title = '"+title+"'", True)
    if len(response)>0:
        return  response[0][0], response[0][1], response[0][3].split('/')[-1]
    else:
        return '', '', ''

def make_article(title, article, image):
    """
    Добавляет запись
    """ 
    return sql_work("INSERT INTO Articles VALUES ('"+title+
            "', '"+article+
            "', '"+datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')+
            "', '"+'/static/images/'+image+
            "', '"+str(uuid.uuid4())+
            "')",False)

def make_file():
    """
    Удаляет старый и добавляет новый файл
    """ 
    os.chdir(os.path.join(os.path.dirname(__file__), 'sql'))
    os.remove('main.db')
    sql_work('''CREATE TABLE Articles (Title text, Article text, Date text, Image text, Id text)''',False)
    sql_work('''CREATE TABLE Comments (Comment text, Date text, IdArticle text, Id text, Ip text, ListTo text)''',False)
    sql_work('''CREATE TABLE Preview (Id text, Title text, Article text, Image text)''',False)
    sql_work("INSERT INTO Preview VALUES ('preview', '', '', '')",False)
    sql_work('''CREATE TABLE Users (Ip text, Date text, Url text)''',False)
    sql_work('''CREATE TABLE BlockList (Ip text, DateFrom text, DateTo text, Comment text, Actual text)''',False)

def make_ip(ip, url):
    """
    Добавляет запись посетителя
    """ 
    return sql_work("INSERT INTO Users VALUES ('"+ip+
                "', '"+datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')+
                "', '"+url+"')",False)

def change_preview(title, article, image):
    """
    Изменяет запись предпросмотра
    """ 
    return sql_work("UPDATE Preview SET Title='"+title+"', Article='"+article+"', Image='"+image+"' WHERE Id='preview'",False)

def return_preview():
    """
    Возвращает запись предпросмотра
    """ 
    return sql_work("SELECT * FROM Preview WHERE Id='preview'", True)[0]

def search_article_id(id_item):
    """
    Ищет запись по ид
    """ 
    return sql_work("SELECT * FROM Articles WHERE Id='"+id_item+"'", True)[0]

def search_comments(id_item):
    """
    Ищет комментарии записи по ид
    """ 
    return sql_work("SELECT * FROM Comments WHERE IdArticle='"+id_item+"' ORDER BY Date", True)

def make_comments(comment, id_item, ip, to):
    """
    Добавляет комментарий для записи
    """ 
    return sql_work("INSERT INTO Comments VALUES ('"+comment+
                "', '"+datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')+
                "', '"+id_item+
                "', '"+str(uuid.uuid4())+
                "', '"+ip+
                "', '"+to+
                "')",False)

def list_titles_for_page(page, items_on_page):
    """
    Возвращает список записей для номера страницы
    """ 
    return sql_work("SELECT Title, Image, Id FROM Articles ORDER BY Date DESC LIMIT "+str(items_on_page)+" OFFSET "+str(page*items_on_page),True)