function reply_click(clicked_id) {
    var input = document.getElementById('to');
    input.value = input.value + clicked_id + ',';
}
