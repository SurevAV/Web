function reply_click(clicked_id) {
    var input = document.getElementById('to');
    if (!input.value.includes(clicked_id)) {
        input.value = input.value + clicked_id + ',';
    }
}
