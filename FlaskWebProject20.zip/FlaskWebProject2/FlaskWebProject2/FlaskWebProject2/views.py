from flask import render_template, request, redirect, url_for
from FlaskWebProject2 import app
import os
import FlaskWebProject2.module_sql_str as modul_sql


def user_ip(request, url):
    if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
        ip = request.environ['REMOTE_ADDR']
    else:
        ip = request.environ['HTTP_X_FORWARDED_FOR']
    modul_sql.make_ip(ip, url)
    return ip


@app.route('/', methods=['Get', "POST"])
def main(): 
    ip = user_ip(request, '/')

    list_pages = [0,1,2,3,4]
    page = 0

    if request.args.get('page'):
        page = int(request.args.get('page'))
        if page>2:
            list_pages = [page-2,page-1,page,page+1,page+2]
            
    return render_template('main.html', 
                           items= modul_sql.list_titles_for_page(page, 10), 
                           view_page = page,
                          for_link = "/view?page="+str(page)+"&id=",
                         list_pages = list_pages,
                         for_link_page = "/?page=",)


@app.route('/view', methods=['Get', "POST"])
def view():   
  
    ip = user_ip(request, '/?page='+request.args.get('id'))

    if request.method == 'POST' and request.form['click'] == 'Добавить комментарий':
        modul_sql.make_comments(request.form['comment'], request.args.get('id'), ip, request.form['list_to'].replace(' ',''))

    comments = modul_sql.search_comments(request.args.get('id'))
    for i in range(len(comments)):
        comments[i] = list(comments[i])
        comments[i][5] = comments[i][5].split(",")
        comments[i].append([])

    for i in comments:
        for item in i[5]:
            for s in comments:
                if s[3] == item:
                    s[6].append(i[3])


    return render_template('view.html', 
                           items=modul_sql.search_article_id(request.args.get('id')), 
                           comments = comments, 
                           link_return = "/?page="+request.args.get('page'))


@app.route('/editor', methods=['Get', 'POST'])
def editor():
    ip = user_ip(request, '/editor')
    preview = modul_sql.return_preview()
    title, article, image = preview[1], preview[2], preview[3] 
    if request.method == 'POST':
        item = request.form['click']
        if item == 'Очистить SQL':
            modul_sql.make_file()
        elif item == 'Добавить запись':
            modul_sql.make_article(request.form['title'], request.form['article'], request.form['image'])
        elif item == 'Найти запись':
            title, article, image = modul_sql.search_article(request.form['title'])
        elif item == 'Обновить запись':
            modul_sql.change_article(request.form['title'],request.form['article'], request.form['image'])
            modul_sql.change_preview(request.form['title'], request.form['article'], request.form['image'])
        elif item == 'Удалить запись':
            modul_sql.delete_comments(modul_sql.id_article(request.form['title']))
            modul_sql.delete_article(request.form['title'])
        elif item == 'Список всех записей':
            article, title = modul_sql.list_titles()
        elif item == 'Предпросмотр':
            modul_sql.change_preview(request.form['title'], request.form['article'], request.form['image'])

            return render_template('preview.html', 
                                   items=[request.form['title'],request.form['article']], 
                           link_return = "/editor")

    return render_template('editor.html',  
                           title = title, 
                           article = article, 
                           image = image)




@app.route('/upload', methods=['Get', 'POST'])
def upload_file():
    ip = user_ip(request, '/upload')
    uploading = 'Файл не выбран'
    try:
        if request.method == 'POST':
            os.chdir(os.path.join(os.path.dirname(__file__), 'static/images'))
            request.files['file'].save(request.files['file'].filename)
            uploading = 'Файл загружен'
    except: uploading = 'Не получилось загрузить файл'
    return render_template('upload.html', uploading = uploading)